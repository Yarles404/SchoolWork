CREATE DATABASE IF NOT EXISTS project2;
USE project2;

CREATE TABLE IF NOT EXISTS users (
	screen_name varchar(50) NOT NULL UNIQUE,
    name varchar(50),
    sub_category varchar(20),
    category varchar(50),
    ofstate varchar(20),
    numFollowers int,
    numFollowing int,
    PRIMARY KEY (screen_name)
);

CREATE TABLE IF NOT EXISTS tweets (
	tid bigint NOT NULL UNIQUE,
    textbody varchar(280),
    retweet_count int,
	retweeted int,
    posted datetime,
    posting_user varchar(50),
    PRIMARY KEY(tid),
	FOREIGN KEY(posting_user) REFERENCES users(screen_name)
		ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS urlused (
	tid bigint,
    url varchar(1000),
    FOREIGN KEY (tid) REFERENCES tweets(tid)
);

CREATE TABLE IF NOT EXISTS tagged (
	tid bigint,
    hashtagname varchar(50),
    FOREIGN KEY (tid) REFERENCES tweets(tid)
);

CREATE TABLE IF NOT EXISTS mentioned (
	tid bigint,
    screen_name varchar(50),
    FOREIGN KEY(tid) REFERENCES tweets(tid),
    FOREIGN KEY(screen_name) REFERENCES users(screen_name)
);

CREATE TABLE IF NOT EXISTS newTweets (
	tid bigint NOT NULL UNIQUE,
    textbody varchar(280),
    retweet_count int,
	retweeted int,
    day_posted int,
    month_posted int,
    year_posted int,
    posting_user varchar(50),
    PRIMARY KEY(tid),
	FOREIGN KEY(posting_user) REFERENCES users(screen_name)
		ON DELETE CASCADE
)

