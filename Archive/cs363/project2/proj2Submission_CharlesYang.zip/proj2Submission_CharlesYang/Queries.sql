use project2;

# Q1
SELECT t.retweet_count, t.textbody, t.posting_user FROM newTweets t
	JOIN users u
		ON u.screen_name = t.posting_user
		AND t.month_posted = 1 
		AND t.year_posted = 2016
	ORDER BY t.retweet_count DESC
	LIMIT 5;

# Q2
SELECT COUNT(DISTINCT u.ofstate) AS statenum, GROUP_CONCAT(DISTINCT u.ofstate) AS states, h.hashtagname FROM tagged h
	JOIN tweets t ON t.tid = h.tid
    JOIN users u
		ON u.screen_name = t.posting_user
		AND u.ofstate != 'na'
    GROUP BY h.hashtagname
    ORDER BY statenum DESC
    LIMIT 5;
    
# Q3
SELECT DISTINCT u.screen_name, u.ofstate FROM users u
	JOIN tweets t ON u.screen_name = t.posting_user
	JOIN tagged h
		ON t.tid = h.tid
		AND h.hashtagname IN ('HappyNewYear', 'NewYear', 'NewYears', 'NewYearsDay')
	ORDER BY u.numFollowers DESC
	LIMIT 12;
    
# Q4 GOP
SELECT u.screen_name, u.sub_category, u.numFollowers FROM users u
	WHERE u.sub_category = "GOP"
	ORDER BY u.numFollowers DESC
	LIMIT 5;

# Q4 democrat
SELECT u.screen_name, u.sub_category, u.numFollowers FROM users u
	WHERE u.sub_category = "democrat"
	ORDER BY u.numFollowers DESC
	LIMIT 5;

# Q5
SELECT DISTINCT h.hashtagname AS hashtag_text, u.ofstate AS states FROM tagged h
	JOIN newTweets t
		ON t.tid = h.tid
        AND t.month_posted = 1
        AND t.year_posted = 2016
    JOIN users u ON u.screen_name = t.posting_user
		AND u.ofstate != 'na'
		AND u.ofstate IN ('Ohio', 'Alaska', 'Alabama')
    ORDER BY h.hashtagname;
    
# Q6
SELECT t.textbody, h.hashtagname, u.screen_name, u.sub_category FROM tagged h
	JOIN newTweets t
		ON t.tid = h.tid
		AND h.hashtagname = 'Ohio'
		AND t.month_posted = 1
        AND t.year_posted = 2016
    JOIN users u
		ON u.screen_name = t.posting_user
		AND u.sub_category IN ('GOP', 'democrat')
        AND u.ofstate = 'Ohio'
	LIMIT 5;
    
# Q7
SELECT u.screen_name AS screen_name, u.ofstate AS state, GROUP_CONCAT(DISTINCT l.url) AS URLs FROM users u
	JOIN newTweets t
		ON u.screen_name = t.posting_user
		AND u.sub_category = 'GOP'
		AND t.month_posted = 1
        AND t.year_posted = 2016
	JOIN urlused l ON t.tid = l.tid
    GROUP BY u.screen_name;

# Q8
SELECT m.screen_name, u1.ofstate, group_concat(DISTINCT t.posting_user), COUNT(m.tid) FROM mentioned m
	JOIN newTweets t
		ON m.tid = t.tid
		AND t.month_posted = 1
        AND t.year_posted = 2016
	JOIN users u
		ON t.posting_user = u.screen_name
		AND u.sub_category = 'GOP'
	JOIN users u1
		ON u1.screen_name = m.screen_name
	GROUP BY m.screen_name
    ORDER BY COUNT(m.tid) DESC
    LIMIT 5;

# Q9
SELECT h.hashtagname, COUNT(h.tid) AS num_uses FROM tagged h
	JOIN newTweets t
		ON t.tid = h.tid
		AND t.month_posted IN (1, 2, 3)
        AND t.year_posted = 2016
    JOIN users u
		ON u.screen_name = t.posting_user
		AND u.sub_category = 'GOP'
	GROUP BY h.hashtagname
	ORDER BY num_uses DESC
	LIMIT 5;