package proj3;

public class testing {
    public static void main(String[] args) {
        Toy test = new Toy();
        test.create();
        System.out.println(test.header());
//        test.insert();
//        test.insert();
//        test.insert();
//        test.insert();
        test.display(0);
        test.search("dumb = T");
        test.search("name = prim");
    }
}

/*













 */