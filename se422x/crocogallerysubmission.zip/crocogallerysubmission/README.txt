Hello, this is Charles Yang
The only people who worked on this project meaningfully is Bhwuwan Joshi and I.
The rest of our team members are:
	Tanay
	Brett
	Carson
	Keshav
I don't know their last name as they aren't really communicating or contributing.
I (Charles Yang) will be speaking with the professor about this shortly, as this isn't sustainable.

Within this directly, all required functionalities are imaged.
Due to limited developer effort, this application is not to up to par.

URL: https://riie2wg5ey.us-east-1.awsapprunner.com/
Password: admin
		^ try a wrong password!

The following routes work AFTER authenticating in the session:
	/
	/login
	/upload

The following routes aren't loading in AWS App Runner, but work locally:
	Note: Search functionality is contained in the gallery page
	/gallery

Source code is in CrocoGallery.zip. It should run.
Please email yarles@iastate.edu if you have any questions.